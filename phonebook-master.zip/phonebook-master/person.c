#include "person.h"
#include <stdlib.h>
#include <string.h>

void write_person(FILE *file, person_t *person)
{
    fprintf(file, "%s\t| %d\t| %s\n",
    person->name, person->age, person->phone);
}

void print_person(person_t *person)
{
    write_person(stdout, person);
}

person_t *read_person(FILE *file)
{
    char name[40];
    int age;
    char phone[30];

    if (fscanf(file, "%s\t| %d\t| %s", name, &age, phone) == 3)
    {
        person_t *p = malloc(sizeof(person_t));
        strcpy(p->name, name);
        p->age = age;
        strcpy(p->phone, phone);
        return p;
    }
    return NULL;
}
