#include "contacts_container.h"
#include <stdlib.h>

contacts_container_t *create_empty_contacts()
{
    contacts_container_t *c = malloc(sizeof(contacts_container_t));
    c->capacity = 4;
    c->size = 0;
    c->persons = malloc(c->capacity * sizeof(person_t *));
    return c;
}

void free_contacts(contacts_container_t *c)
{
    // 1. Освободить все контакты
    for (unsigned i = 0; i < c->size; ++i)
    {
        free(c->persons[i]);
    }

    // 2. Освободить массив указателей
    free(c->persons);

    // 3. Освободить сам контейнер
    free(c);
}

void add_contact(contacts_container_t *c, person_t *p)
{
    if (c->size == c->capacity)
    {
        c->capacity *= 2;
        c->persons = realloc(c->persons, sizeof(person_t *) * c->capacity);
    }

    c->persons[c->size++] = p;
}

void delete_contact(contacts_container_t *c, unsigned i)
{
    free(c->persons[i]);
    for(unsigned k = i+1; k < c->size; ++k)
    {
       c->persons[k-1] = c->persons[k]; 
    }
    c->persons[--c->size] = NULL;
}
