#ifndef PHONEBOOK_CONTACTS_CONTAINER
#define PHONEBOOK_CONTACTS_CONTAINER
#include "person.h"

typedef struct contacts_container
{
    unsigned int capacity; // контейнер с количеством ячеек
    unsigned int size;     // сколько ячеек занято
    person_t **persons;    // массив указателей на контакты
} contacts_container_t;

contacts_container_t *create_empty_contacts();

void free_contacts(contacts_container_t *c);

void add_contact(contacts_container_t *c, person_t *p);

void delete_contact(contacts_container_t *c, unsigned i);

#endif
