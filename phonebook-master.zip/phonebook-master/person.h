#ifndef PHONEBOOK_PERSON
#define PHONEBOOK_PERSON
#include <stdio.h>

typedef struct person
{
    char name[40];
    int age;
    char phone[30];
} person_t;

void write_person(FILE *file, person_t *person);

void print_person(person_t *person);

person_t *read_person(FILE *file);

#endif 
