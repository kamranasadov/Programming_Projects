#include "contacts_container.h"
#include <stdlib.h>
#include <string.h>

void print_help()
{
    printf("Possible commands:\n");
    printf("help\t- show this help\n");
    printf("show\t- print all contacts\n");
    printf("add\t- add contact\n");
    printf("delete\t- delete contact\n");
    printf("find\t- find contact\n");
    printf("save\t- save all contacts to phones.txt\n");
    printf("exit\t- close program\n");
}

int main(int argc, char **argv)
{
    contacts_container_t *c = create_empty_contacts();

    FILE *fi = fopen("phones.txt", "r");
    if (fi != NULL)
    {
        person_t *p = read_person(fi);
        while (p != NULL)
        {
            add_contact(c, p);
            p = read_person(fi);
        }

        fclose(fi);
    }

    char input[80];
    print_help();
    while (1)
    {
        printf("Input the command: ");
        scanf("%s", input);
        if (strcmp(input, "exit") == 0)
        {
            break;
        }
        else if (strcmp(input, "help") == 0)
        {
            print_help();
        }
        else if (strcmp(input, "add") == 0)
        {
            person_t *p = malloc(sizeof(person_t));
            printf("Input the name: ");
            scanf("%s", p->name);
            printf("Input the age: ");
            scanf("%d", &p->age);
            printf("Input the phone: ");
            scanf("%s", p->phone);
            add_contact(c, p);
            printf("Contact successfully created: ");
            print_person(p);
            printf("You need save contacts to file!\n");
        }
        else if (strcmp(input, "save") == 0)
        {
            fi = fopen("phones.txt", "w");
            if (fi == NULL)
            {
                printf("Couldn't save contacts to file phones.txt!\n");
            }
            else
            {
                for (unsigned i = 0; i < c->size; ++i)
                {
                    write_person(fi, c->persons[i]);
                }
                fclose(fi);
                printf("Contacts successfully saved to file phones.txt!\n");
            }
        }
        else if (strcmp(input, "show") == 0)
        {
            for (unsigned i = 0; i < c->size; ++i)
            {
                print_person(c->persons[i]);
            }
        }
        else if (strcmp(input, "delete") == 0)
        {
            for (unsigned i = 0; i < c->size; ++i)
            {
                printf("%3d. ", i+1);
                print_person(c->persons[i]);
            }

            int which_one;
            printf("Input which one:");
            scanf("%d", &which_one);
            delete_contact(c, which_one-1);
            printf("Contact successfully deleted!\n");
            printf("You need save contacts to file!\n");
        }
        else if (strcmp(input, "find") == 0)
        {
            while (1)
            {
                printf("\nFind by name, age or phone?\nPlease select\n");
                scanf("%s", input);

                if (strcmp(input, "name") == 0)
                {
                    printf("\nInput name:\n");
                    scanf("%s", input);
                    for (unsigned i = 0; i < c->size; ++i)
                    {
                        if (strcmp(c->persons[i]->name, input) == 0)
                        {
                            print_person(c->persons[i]);
                        }
                    }
                }
                
                else if (strcmp(input, "age") == 0)
                {
                    printf("\nInput age:\n");
                    int find_age;
                    scanf("%d", &find_age);
                    for (unsigned i = 0; i < c->size; ++i)
                    {
                        if (c->persons[i]->age == find_age)
                        {
                            print_person(c->persons[i]);
                        }
                    }
                }  
                else if (strcmp(input, "phone") == 0)
                {
                    printf("\nInput phone:\n");
                    scanf("%s", input);
                    for (unsigned i = 0; i < c->size; ++i)
                    {
                        if (strcmp(c->persons[i]->phone, input) == 0)
                        {
                            print_person(c->persons[i]);
                        }
                    }
                }
                else
                {
                    printf("\nI don't understand you\n");
                }
            }
        }  
        else
        {
            printf("\nUnsupported command: %s\n", input);
        }
    }
    
    free_contacts(c);
    return 0;
}