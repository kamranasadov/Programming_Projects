#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

typedef struct person
{
    int age;
    char name[20];
} person_t;

typedef union person_bytes
{
    person_t p;
    unsigned char bytes[sizeof(person_t)];
} person_bytes_t;

struct byte
{
    unsigned a0 : 1;
    unsigned a1 : 1;
    unsigned a2 : 5;
    unsigned long a7 : 31;
};

// 00000000 00000000 00000000 00000000 01000000 00100100 00000000 00000001

int main(int argc, char **argv)
{
    int8_t i8;
    uint32_t u32;

    person_bytes_t a;

    printf("Input name: ");
    scanf("%s", a.p.name);
    printf("Input age: ");
    scanf("%d", &a.p.age);

    printf("Debug info:\n");
    for (int i = 0; i < sizeof(person_t); ++i)
    {
        printf("%d ", a.bytes[i]);
    }
    printf("\n");

    // --------------------

    person_bytes_t b;
    for (int i = 0; i < sizeof(person_t); ++i)
    {
        b.bytes[i] = a.bytes[i];
    }

    printf("%s - %d\n", b.p.name, b.p.age);
}
