var service_en_cours = false;

function randomMoney(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    euros = Math.floor(Math.random() * (max - min)) + min;
    cents = Math.floor(Math.random() * 10) / 10.0;
    return euros + cents;
} 

function init() {
  if (service_en_cours) return;

  var clients = document.getElementById("client-num");
  clients.textContent = +clients.textContent + 1;

  var sum = randomMoney(1, 50);
  document.getElementById("sum").textContent = sum;
  document.getElementById("pay").textContent = (Math.round(sum / 10) + 1) * 10;

  var status = document.getElementById("status");
  status.textContent = "Service en cours";
  status.style.fontStyle = "italic";
  status.style.color = "gray";

  document.getElementById("change").textContent = 0;

  service_en_cours = true;
}

function toggleCashbox(element) {
  var cashbox = document.getElementById("cashbox");
  cashbox.hidden = !cashbox.hidden;
  element.textContent = cashbox.hidden ? "Ouvrir le tiroir caisse" : "Fermer le tiroir caisse";
}

function takeMoney(element) {
  if (!service_en_cours) return;
  var value = +element.textContent;
  var change = document.getElementById("change");
  change.textContent =
    Math.round((+change.textContent + value) * 10) / 10.0;
}

function giveChange() {
  if (!service_en_cours) return;

  var sum = +document.getElementById("sum").textContent;
  var pay = +document.getElementById("pay").textContent;
  var change = +document.getElementById("change").textContent;

  var status = document.getElementById("status");
  status.style.fontStyle = "normal";

  if (pay === sum + change) {
    status.textContent = "Le compte est bon";
    status.style.color = "green";
  } else {
    var unsuccessful = document.getElementById("unsuccessful-client-num");
    unsuccessful.textContent = +unsuccessful.textContent + 1;
    status.style.color = "red";
    if (pay - sum < change) {
      status.textContent = "Rendu plus que nécessaire !";
    } else {
      status.textContent = "Il manque de la monnaie !";
    }
  }

  service_en_cours = false;
}

function addMoneyListeners() {
  for (e of document.getElementsByClassName("paper")) {
    e.setAttribute("onclick", "takeMoney(this);");
  }
  for (e of document.getElementsByClassName("coin")) {
    e.setAttribute("onclick", "takeMoney(this);");
  }
}

window.onload = addMoneyListeners;
