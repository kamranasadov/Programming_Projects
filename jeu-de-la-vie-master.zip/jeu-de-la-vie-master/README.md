# Jeu de la Vie

Nous utilisons des tags pour demontrer le niveau danslequel on est situe. 
Les consignes de numeration sont suivantes: `0.x`, ou `x` est le numero de mon niveau.