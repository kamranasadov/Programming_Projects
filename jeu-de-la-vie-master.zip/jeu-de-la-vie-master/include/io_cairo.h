#ifndef __IO_CAIRO__
#define __IO_CAIRO__ 

#include <stdio.h>
#include <stdlib.h>
#include <cairo.h>
#include <cairo-xlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "grille.h"
#include "jeu.h"

#define SIZEX 1500
#define SIZEY 1000
#define X0 50
#define Y0 50
#define DEPX 20
#define DEPY 100

//fonction d'affichage
void paint(cairo_surface_t *surface ,grille g);
//fonction pour demarrer l'affichage grapghique
void run_game(grille *g , grille *gc);

#endif

