/**
 * \brief pour la documentation des fonctions: voir \c grille.h
 *
 * \file io.c 
 * code sources pour les grilles
 * \author ASADOV Kamran
 */

#include "../include/io.h"

/**
 * \param c int nombre de cellules de la colonne
 * \return void "affiche"
 */
void affiche_trait (int c){
	int i;
	for (i=0; i<c; ++i) printf ("|---");
	printf("|\n");
	return;
}
/**
 * \param c int nombre de cellules sur la ligne
 * \param ligne int* ligne tableau qui indique si la cellule est morte ou vivante
 * \return void "affichage d'une ligne de la grille"
 */
void affiche_ligne (int c, int* ligne){
	int i;
	for (i=0; i<c; ++i) 
		if (ligne[i] == 0 )
			printf ("|   ");
		else if (ligne[i] == -1)
			printf ("| X ");
		else
			printf ("| %d ", ligne[i]);

	printf("|\n");
	return;

}
/**
 * \param g grille
 * \return void "affichage d'une grille"
 */
void affiche_grille (grille g){
	int i, l=g.nbl, c=g.nbc;
	printf("\n");
	affiche_trait(c);
	for (i=0; i<l; ++i) {
		affiche_ligne(c, g.cellules[i]);
		affiche_trait(c);
	}	
	printf("\n"); 
	return;
}
/**
 * \param g grille à effacer
 * \return void "effacement d'une grille"
 */
void efface_grille (grille g){
	printf("\n\e[%dA",g.nbl*2 + 5); 
}
/**
 * \param g pointeur sur la grille
 * \param gc pointeur sur la copie de la grille
 * \return void "commence le jeu"
 */
void debut_jeu(grille *g, grille *gc){
	char c = getchar();
	int cyclique = 1;
	int vieillissement = 0;
	int tempsDeEvolution = 0;
	while (c != 'q') // touche 'q' pour quitter
	{ 
		switch (c) {
			case 'c':
			{
				if(cyclique == 1)
				{
					compte_voisins_vivants = compte_voisins_vivants_non_cyclique ;
					cyclique = 0;
				}else{
					compte_voisins_vivants = compte_voisins_vivants_cyclique ;
					cyclique=1;
				}
				printf("\033[A\33[2K\r\n");
				break ;
			}
			case 'v':
			{
				if(vieillissement == 1)
				{
					pt_set_vivante = set_vivante;
					vieillissement = 0;
				}else{
					pt_set_vivante = set_vivante_vieillissement;
					vieillissement = 1;
				}

				break;
			}
			case '\n' : 
			{ // touche "entree" pour évoluer

				evolue(g,gc);
				efface_grille(*g);
				printf("\033[A\33[2K\r\n");
				printf("Le temps d'évolution de la grille est %d\t", ++tempsDeEvolution);
				if(cyclique == 1 )
				{
					printf("\tcyclique = Activé\t");
				}else{
					printf("\tcyclique = Désactivé\t");
				}
				if(vieillissement == 1 )
				{
					printf("\tvieillissement = Activé\t");
				}else{
					printf("\tvieillissement = Désactivé\t");
				}
				affiche_grille(*g);
				break;
			}
			case 'n' :
			{
				char name[100];
				printf("Entrez le nom du fichier: ");
				scanf("%s", name);
				printf("\033[2J\033[1;1H"); //effacer l'ecran
				libere_grille(g);
				init_grille_from_file(name, g);
				alloue_grille (g->nbl, g->nbc, gc);
				affiche_grille(*g);
				break;
			}
			default : 
			{ // touche non traitée
				printf("\n\e[1A");
				break;
			}
		}
		c = getchar(); 
	}
	return;	
}
