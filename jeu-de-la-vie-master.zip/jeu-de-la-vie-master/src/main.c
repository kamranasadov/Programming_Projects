/**
 * \file
 * fichier main 
 * \author ASADOV Kamran
 */

#include <stdio.h>

#include "../include/grille.h"
#include "../include/jeu.h"

#ifdef MODE
#include "../include/io.h"
#else 
#include "../include/io_cairo.h"
#endif

int main (int argc, char ** argv) {
	
	if (argc != 2 )
	{
		printf("usage : main <fichier grille>");
		return 1;
	}

	grille g, gc;
	init_grille_from_file(argv[1],&g);
	alloue_grille (g.nbl, g.nbc, &gc);
	
	#ifdef MODE
		affiche_grille(g);
		debut_jeu(&g, &gc);
	#else
		run_game(&g ,&gc);
	#endif
	
	libere_grille(&g);
	libere_grille(&gc);
	return 0;
}
