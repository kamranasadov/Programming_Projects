#include "../include/io_cairo.h"

void paint(cairo_surface_t *surface, grille g ){
	// creer masque cairo
	cairo_t *cr;
	cr=cairo_create(surface);

	// le font
	cairo_set_source_rgb (cr, 255.0, 255.0, 255.0);
	cairo_paint(cr);
	
	// ligne
	cairo_set_source_rgb (cr, 0.0, 0.0, 0.0);
	int l = g.nbl ;
	int c = g.nbc ;
	float dimducel = 50;
	float x = 1.0 ;
	for(int i = 0  ; i < l+2; i++){
		cairo_move_to (cr, Y0, x);
		cairo_line_to(cr, (c+1)*dimducel,x);	
		x+= dimducel ;
	}
	x = 1.0 ;
	for (int i = 0; i < c+2 ; i++){
		cairo_move_to (cr, x, X0);
		cairo_line_to(cr, x,(l+1)*dimducel);
		x+= dimducel ;
	}
	cairo_set_line_width (cr, 2);
	cairo_stroke (cr);

	//affiche cellule 
	for(int i = 0; i < l ; i++){
		for(int j = 0 ; j < c ; j++ ){
			if(est_vivante(i,j,g)){
				cairo_rectangle(cr, (Y0+(j*dimducel))+2,(X0+(i*dimducel))+2,dimducel-2, dimducel-2);
				cairo_set_source_rgb (cr, 0.0,255.0, 0.0);
				cairo_fill(cr);	
			}
			else if(g.cellules[i][j] == -1 ){
				cairo_rectangle(cr, (Y0+(j*dimducel))+2,(X0+(i*dimducel))+2,dimducel-2, dimducel-2);
				cairo_set_source_rgb (cr, 0.0,0.0, 255.0);
				cairo_fill(cr);	
			}
		}
	}

	cairo_destroy(cr); // detruire masque cairo
}

void run_game(grille *g ,grille *gc){
		// X11 display
	Display *dpy;
	Window rootwin;
	Window win;
	XEvent e;
	int scr;
	int q = 0 ;
	int c = 1 ;
	int v = 0 ;
	int i = 0 ;
	char str[12];
	KeySym key ;
	char keybuf[8] ;
	
	// init display
	if(!(dpy=XOpenDisplay(NULL))) {
		fprintf(stderr, "ERROR: Could not open display\n");
		exit(1);
	}

	scr=DefaultScreen(dpy);
	rootwin=RootWindow(dpy, scr);

	win=XCreateSimpleWindow(dpy, rootwin, 1, 1, SIZEX, SIZEY, 0, 
			BlackPixel(dpy, scr), BlackPixel(dpy, scr));

	XStoreName(dpy, win, "jeu de la vie");
	XSelectInput(dpy, win, ExposureMask|ButtonPressMask|KeyPressMask | KeyReleaseMask);
	XMapWindow(dpy, win);
	
	// create cairo surface
	cairo_surface_t *cs; 
	cs=cairo_xlib_surface_create(dpy, win, DefaultVisual(dpy, 0), SIZEX, SIZEY);

	// run the event loop
	while(q == 0)
	{
		
		//sprintf(str, "%d", i);
		paint(cs,*g);
    	cairo_t *cr = cairo_create(cs);
    	cairo_select_font_face (cr, "monospace", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
		cairo_set_font_size (cr, 14);
		cairo_set_source_rgb (cr, 0.0, 0.0, 0.0);
    	cairo_move_to (cr, X0, Y0-20);
	    cairo_show_text (cr, "temps d'evolution de la grille est ");
	    cairo_show_text (cr, str);
	    cairo_show_text (cr, " cyclique = ");
   		(c==0?cairo_show_text(cr,"NON"):cairo_show_text(cr,"OUI"));
    	cairo_show_text (cr, " vieillisement = ");
    	(v==0?cairo_show_text(cr,"NON"):cairo_show_text(cr,"OUI"));
    	cairo_destroy(cr);
		XNextEvent(dpy, &e);
		
		switch(e.type)
		{
			case ButtonPress:
			{
				switch(e.xbutton.button)
				{
					case Button1:
					{
						evolue(g,gc);
						i++;
						break;
					}
					case Button3:
					{
						q=1 ;
						break;
					}
				}
			}
			case KeyPress:
			{
				XLookupString(&e.xkey,keybuf,sizeof(keybuf) , &key ,NULL);
				switch(key)
				{
					case /*65293*/ 0xFF0D : { // touche "entree" pour évoluer

						evolue(g,gc);
						i++ ;
						break;
					}
					case 'c':
					{
						if(c == 1){
							c = 0 ; 
							compte_voisins_vivants = compte_voisins_vivants_non_cyclique;
						}	
						else{
							c = 1 ;
							compte_voisins_vivants = compte_voisins_vivants_cyclique; 
						}
						break ; 
					}
					case 'v':
					{
						v =  (v+1)%2 ;
						if(v==0) pt_set_vivante = set_vivante;
						else pt_set_vivante = set_vivante_vieillissement;
						break;
					}
					case 'q':
					{
						q=1 ;
						break;
					}
					case 'n':
					{
						char string[100];
						printf("entre une chaine de charactere : ");
						scanf( " %99[^\n]", string);
						libere_grille(g) ;
						init_grille_from_file(string,g);
						libere_grille(gc) ;
						alloue_grille (g->nbl, g->nbc, gc);
						for(int j = 0 ; j < 1 ; j++)
							printf("\033[A\33[2K\r");
						i = 0 ;
						break ;
					}
					case 'o':
					{
					int o = est_oscillante(*g) ;
					cairo_t *cr = cairo_create(cs);
   				 	cairo_select_font_face (cr, "monospace", CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_NORMAL);
					cairo_set_font_size (cr, 14);
					cairo_set_source_rgb (cr, 1, 1, 1);
    				cairo_move_to (cr, DEPX, DEPY-60);
    				if(o == -1)
    				{
    					cairo_show_text (cr, "grille vide");
    				}
    				else if(o == 1)
    				{
    					cairo_show_text (cr, "grille statique");
    				}
    				else if(o == 0 )
    				{
    					cairo_show_text (cr, "grille pas oscillante");
    				}
    				else
    				{
    					cairo_show_text (cr, "grille oscillante de periode ");
    					sprintf(str, "%d", o);
						cairo_show_text (cr, str);
						}
						XNextEvent(dpy, &e);
						XNextEvent(dpy, &e);
						cairo_destroy(cr);
						break ;
					}
					case 'b':{
						XNextEvent(dpy, &e);
						printf("%x\n",e.xkey.keycode);
						break;
					}
				}
			}
		}
	}				
	cairo_surface_destroy(cs); // detruire surface cairo
	XCloseDisplay(dpy); // fermer le display
}