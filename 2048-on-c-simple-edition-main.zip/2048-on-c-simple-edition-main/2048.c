// UNIVERSITE PARIS NANTERRE L2 MIASHS

// KAMRAN ASADOV TD3 et CHIACHIA NDONGO CHRIST TD4

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <termios.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <signal.h>

#define SIZE 4
uint32_t score=0;


void obtenirCouleur(uint8_t valeur, char *couleur, size_t longeur) {
	uint8_t original[] = {8,255,231,0,230,0,215,0,208,0,202,7,196,7,227,0,226,0,221,0,220,0,214,0,234,255,233,255,232,255,255,0};

	uint8_t *fondarriere = original+0;
	uint8_t *fontdevant = original+1;
	if (valeur > 0) while (valeur--) {
		if (fondarriere+2<original+sizeof(original)) {
			fondarriere+=2;
			fontdevant+=2;
		}
	}
	snprintf(couleur,longeur,"\033[38;5;%d;48;5;%dm",*fontdevant,*fondarriere);
}

void DessinerBoard(uint8_t board[SIZE][SIZE]) {
	uint8_t x,y;
	char couleur[40], reset[] = "\033[m";
	printf("\033[H");

	printf("2048 %15d points\n\n",score);

	for (y=0;y<SIZE;y++) {
		for (x=0;x<SIZE;x++) {
			obtenirCouleur(board[x][y],couleur,40);
			printf("%s",couleur);
			printf("       ");
			printf("%s",reset);
		}
		printf("\n");
		for (x=0;x<SIZE;x++) {
			obtenirCouleur(board[x][y],couleur,40);
			printf("%s",couleur);
			if (board[x][y]!=0) {
				char s[8];
				snprintf(s,8,"%u",(uint32_t)1<<board[x][y]);
				uint8_t t = 7-strlen(s);
				printf("%*s%s%*s",t-t/2,"",s,t/2,"");
			} else {
				printf("   ·   ");
			}
			printf("%s",reset);
		}
		printf("\n");
		for (x=0;x<SIZE;x++) {
			obtenirCouleur(board[x][y],couleur,40);
			printf("%s",couleur);
			printf("       ");
			printf("%s",reset);
		}
		printf("\n");
	}
	printf("\n");
	printf("        a,s,d,w or q        \n");
	printf("\033[A"); // une ligne plus haut
}

uint8_t TrouverCible(uint8_t array[SIZE],uint8_t x,uint8_t stop) {
	uint8_t t;
	// si la position est deja sur la premiere, ne pas evaluer
	if (x==0) {
		return x;
	}
	for(t=x-1;;t--) {
		if (array[t]!=0) {
			if (array[t]!=array[x]) {
				// merge pas possible, prendre prochaine position
				return t+1;
			}
			return t;
		} else {
			// pas aller plus loin, retourner au celui la
			if (t==stop) {
				return t;
			}
		}
	}
	return x;
}

bool slideArray(uint8_t array[SIZE]) {
	bool succes = false;
	uint8_t x,t,stop=0;

	for (x=0;x<SIZE;x++) {
		if (array[x]!=0) {
			t = TrouverCible(array,x,stop);
			// si cible est pas la position originale , alors bouger ou merger
			if (t!=x) {
				// si la cible est zero
				if (array[t]==0) {
					array[t]=array[x];
				} else if (array[t]==array[x]) {
					// merger
					array[t]++;
					// augmenter le score
					score+=(uint32_t)1<<array[t];
					// on met stop pour pas avoir un merge 2 fois
					stop = t+1;
				}
				array[x]=0;
				succes = true;
			}
		}
	}
	return succes;
}

void rotationDuBoard(uint8_t board[SIZE][SIZE]) {
	uint8_t i,j,n=SIZE;
	uint8_t tmp;
	for (i=0; i<n/2; i++) {
		for (j=i; j<n-i-1; j++) {
			tmp = board[i][j];
			board[i][j] = board[j][n-i-1];
			board[j][n-i-1] = board[n-i-1][n-j-1];
			board[n-i-1][n-j-1] = board[n-j-1][i];
			board[n-j-1][i] = tmp;
		}
	}
}

bool moveUp(uint8_t board[SIZE][SIZE]) {
	bool succes = false;
	uint8_t x;
	for (x=0;x<SIZE;x++) {
		succes |= slideArray(board[x]);
	}
	return succes;
}

bool BougerGauche(uint8_t board[SIZE][SIZE]) {
	bool succes;
	rotationDuBoard(board);
	succes = moveUp(board);
	rotationDuBoard(board);
	rotationDuBoard(board);
	rotationDuBoard(board);
	return succes;
}

bool BougerEnBas(uint8_t board[SIZE][SIZE]) {
	bool succes;
	rotationDuBoard(board);
	rotationDuBoard(board);
	succes = moveUp(board);
	rotationDuBoard(board);
	rotationDuBoard(board);
	return succes;
}

bool BougerDroite(uint8_t board[SIZE][SIZE]) {
	bool succes;
	rotationDuBoard(board);
	rotationDuBoard(board);
	rotationDuBoard(board);
	succes = moveUp(board);
	rotationDuBoard(board);
	return succes;
}

bool TrouverPaireEnBas(uint8_t board[SIZE][SIZE]) {
	bool succes = false;
	uint8_t x,y;
	for (x=0;x<SIZE;x++) {
		for (y=0;y<SIZE-1;y++) {
			if (board[x][y]==board[x][y+1]) return true;
		}
	}
	return succes;
}

uint8_t comptervide(uint8_t board[SIZE][SIZE]) {
	uint8_t x,y;
	uint8_t compter=0;
	for (x=0;x<SIZE;x++) {
		for (y=0;y<SIZE;y++) {
			if (board[x][y]==0) {
				compter++;
			}
		}
	}
	return compter;
}

bool FinJeu(uint8_t board[SIZE][SIZE]) {
	bool fini = true;
	if (comptervide(board)>0) return false;
	if (TrouverPaireEnBas(board)) return false;
	rotationDuBoard(board);
	if (TrouverPaireEnBas(board)) fini = false;
	rotationDuBoard(board);
	rotationDuBoard(board);
	rotationDuBoard(board);
	return fini;
}

void AjouterAleatoire(uint8_t board[SIZE][SIZE]) {
	static bool initialize = false;
	uint8_t x,y;
	uint8_t r,len=0;
	uint8_t n,list[SIZE*SIZE][2];

	if (!initialize) {
		srand(time(NULL));
		initialize = true;
	}

	for (x=0;x<SIZE;x++) {
		for (y=0;y<SIZE;y++) {
			if (board[x][y]==0) {
				list[len][0]=x;
				list[len][1]=y;
				len++;
			}
		}
	}

	if (len>0) {
		r = rand()%len;
		x = list[r][0];
		y = list[r][1];
		n = (rand()%10)/9+1;
		board[x][y]=n;
	}
}

void initBoard(uint8_t board[SIZE][SIZE]) {
	uint8_t x,y;
	for (x=0;x<SIZE;x++) {
		for (y=0;y<SIZE;y++) {
			board[x][y]=0;
		}
	}
	AjouterAleatoire(board);
	AjouterAleatoire(board);
	DessinerBoard(board);
	score = 0;
}

void DefinirEntreeTamponnee(bool enable) {
	static bool allume = true;
	static struct termios vieux;
	struct termios nouveau;

	if (enable && !allume) {
		// reinitialiser les vieux reglages
		tcsetattr(STDIN_FILENO,TCSANOW,&vieux);
		// mettre le nouveau etat
		allume = true;
	} else if (!enable && allume) {
		// reglages terminal pour l'entree normale
		tcgetattr(STDIN_FILENO,&nouveau);
		// on veut garder les vieux reglages pour reinitialiser a la fin
		vieux = nouveau;
		// eteindre mode canonique
		nouveau.c_lflag &=(~ICANON & ~ECHO);
		// mettre les nouvelles reglages immediatement
		tcsetattr(STDIN_FILENO,TCSANOW,&nouveau);
		// mettre le nouveau etat
		allume = false;
	}
}



int main(int argc, char *argv[]) {
	uint8_t board[SIZE][SIZE];
	char c;
	bool succes;


	printf("\033[?25l\033[2J");


	initBoard(board);
	DefinirEntreeTamponnee(false);
	while (true) {
		c=getchar();
		if (c == -1){
			puts("\nErreur! Je ne comprends pas votre obtenir!");
			break;
		}
		switch(c) {
			case 97:	// 'a' bouton
				succes = BougerGauche(board);  break;
			case 100:	// 'd' bouton
				succes = BougerDroite(board); break;
			case 119:	// 'w' bouton
				succes = moveUp(board);    break;
			case 115:	// 's' bouton
				succes = BougerEnBas(board);  break;
			default: succes = false;
		}
		if (succes) {
			DessinerBoard(board);
			usleep(150000);
			AjouterAleatoire(board);
			DessinerBoard(board);
			if (FinJeu(board)) {
				printf("         JEU FINI          \n");
				break;
			}
		}
		if (c=='q') {
			printf("        QUITTER? (y/n)         \n");
			c=getchar();
			if (c=='y') {
				break;
			}
			DessinerBoard(board);
		}
		if (c=='r') {
			printf("       REDEMARRER? (y/n)       \n");
			c=getchar();
			if (c=='y') {
				initBoard(board);
			}
			DessinerBoard(board);
		}
	}
	DefinirEntreeTamponnee(true);
	
	printf("\033[?25h\033[m");

	return EXIT_SUCCESS;
}
